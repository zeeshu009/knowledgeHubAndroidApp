package com.mistercoding.knowledgehub

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class SecondScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second_screen2)


        val btn = findViewById<Button>(R.id.button);
        val yt  = findViewById<CardView>(R.id.youtube);
        val google = findViewById<CardView>(R.id.google);

        btn.setOnClickListener(){
            intent = Intent(Intent.ACTION_DIAL,(Uri.parse("tel:03062972172")));
            startActivity(intent);
        }

        yt.setOnClickListener(){
            intent = Intent(Intent.ACTION_VIEW,(Uri.parse("https://www.youtube.com/")))
            startActivity(intent);
        }

        google.setOnClickListener(){
            val googleUrl = "https://www.google.com"
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setData(Uri.parse(googleUrl))
            startActivity(intent)

        }

    }
}